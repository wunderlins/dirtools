define(
({
	invalidMessage: "Vnesena vrednost ni veljavna.",
	missingMessage: "Ta vrednost je zahtevana.",
	rangeMessage: "Ta vrednost je izven območja."
})
);
