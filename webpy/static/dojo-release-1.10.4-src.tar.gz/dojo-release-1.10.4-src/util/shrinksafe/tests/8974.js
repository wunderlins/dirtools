result = "";

(function() {
    var _3 = -1;
    var variableone = 1, variabletwo = 2, variable3 = 3;
    result = _3;
})();
