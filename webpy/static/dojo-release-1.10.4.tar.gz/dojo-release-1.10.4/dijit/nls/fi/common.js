//>>built
define("dijit/nls/fi/common",({buttonOk:"OK",buttonCancel:"Peruuta",buttonSave:"Tallenna",itemClose:"Sulje"}));
