//>>built
define("dijit/form/RadioButton",["dojo/_base/declare","./CheckBox","./_RadioButtonMixin"],function(_1,_2,_3){
return _1("dijit.form.RadioButton",[_2,_3],{baseClass:"dijitRadio"});
});
