//>>built
define("dijit/form/nls/it/ComboBox",({previousMessage:"Scelte precedenti",nextMessage:"Scelte successive"}));
